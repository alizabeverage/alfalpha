# alfalpha
Elemental abundance fitting code based on the Conroy+18 MILES+IRTF+MIST SSP models and ATLAS response functions

Make sure you have "ALFA_HOME", "ALFA_OUT", and "ALFA_INFILES" evironemnt variables set
