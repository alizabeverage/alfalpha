# alfalpha
Elemental abundance fitting code based on the Conroy+18 MILES+IRTF+MIST SSP models and ATLAS response functions

Make sure you have "ALFA_OUT", and "ALFA_INFILES" evironemnt variables set
"ALFA_INFILES": Location of model grids (typically under alfalpha/infiles/)
"ALFA_OUT": Where the output files are saved (can also be manually defined in alfa_template.py)
